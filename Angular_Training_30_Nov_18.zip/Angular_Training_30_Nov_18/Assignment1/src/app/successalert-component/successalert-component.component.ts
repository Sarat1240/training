import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-successalert-component',
  templateUrl: './successalert-component.component.html',
  styleUrls: ['./successalert-component.component.css']
})
export class SuccessalertComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
