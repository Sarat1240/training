import { browser, by, element } from 'protractor';

export class AppPage {
  navigateTo() {
    return browser.get('/');
  }

  getTitleText() {
    return element(by.css('app-home h2')).getText();
  }

  getAboutButton()
  {
    return element(by.css('[routerLink="/about"]'));
  }

  getAboutText()
  {
    return element(by.css('app-about h2'));
  }
}
