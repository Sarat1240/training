import {LikeComponent} from './like.component';
let component = new LikeComponent(10,true);
component.onclick();
console.log(`Like Count: ${component.Count}, Status: ${component.Status}`);