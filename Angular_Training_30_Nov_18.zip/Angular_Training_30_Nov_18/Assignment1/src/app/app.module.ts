import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SuccessalertComponentComponent } from './successalert-component/successalert-component.component';
import { WarningsalertComponentComponent } from './warningsalert-component/warningsalert-component.component';

@NgModule({
  declarations: [
    AppComponent,
    SuccessalertComponentComponent,
    WarningsalertComponentComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
