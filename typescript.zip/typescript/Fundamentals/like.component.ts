export class LikeComponent {
    constructor(private count: number, private status: boolean) {

    }
    onclick() {
        if (this.status) {
            this.count++;
            this.status = false;
        } else {
            this.count--;
            this.status = true;
        }
    }
    get Count() {
        return this.count;
    }
    get Status() {
        return this.status;
    }
}