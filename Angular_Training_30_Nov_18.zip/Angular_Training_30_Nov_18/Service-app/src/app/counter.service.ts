import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CounterService {
  activeToInactiveCount = 0;
  inactiveToAtiveCount = 0;

  incrementActiveToInActive()
  {
    this.activeToInactiveCount++;
    console.log('Active to Inactive:'+ this.activeToInactiveCount);
  }

  incrementInActiveToActive()
  {
    this.inactiveToAtiveCount++;
    console.log('InActive to active:'+ this.inactiveToAtiveCount);
  }
  constructor() { }
}
