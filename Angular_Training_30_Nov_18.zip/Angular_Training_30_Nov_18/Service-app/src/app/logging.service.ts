import { Injectable } from "@angular/core";

@Injectable({
    providedIn:'root'
})
export class LoggingService
{
    logStatusChanged(status:string)
    {
        console.log('Server status changed, new status:' +status);
    }
}