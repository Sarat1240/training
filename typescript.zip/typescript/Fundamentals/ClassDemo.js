var ClassDemo = /** @class */ (function () {
    function ClassDemo(a, b) {
        this.x = a;
        this.y = b;
    }
    Object.defineProperty(ClassDemo.prototype, "X", {
        get: function () {
            return this.y;
        },
        set: function (value) {
            if (value < 0) {
                throw new Error('value cant less than 0');
            }
        },
        enumerable: true,
        configurable: true
    });
    return ClassDemo;
}());
var obj = new ClassDemo(10, -1);
obj.X = 12;
console.log(obj.X);
//let obj1 = new ClassDemo(20);
//obj.draw();
//obj1.draw();
