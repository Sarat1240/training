import { Component, OnInit, Input, OnChanges, SimpleChanges, ViewChild, ElementRef, DoCheck, AfterContentInit, AfterViewChecked, AfterViewInit, AfterContentChecked, OnDestroy, ContentChild } from '@angular/core';

@Component({
  selector: 'app-server-content',
  templateUrl: './server-content.component.html',
  styleUrls: ['./server-content.component.css']
})
export class ServerContentComponent implements OnInit,OnChanges,DoCheck,
AfterContentInit,AfterViewChecked,AfterViewInit,AfterContentChecked,OnDestroy {
  @Input('srvElement')
  element:{type:string,name:string,content:string};
  @Input() name:string;
  @ViewChild('heading') header: ElementRef;
  @ContentChild('paragraphContent') paragraph:ElementRef;
  constructor() { 
    console.log('Constructor is called!!');
  }
  ngOnChanges(changes:SimpleChanges)
  {
    console.log('Onchanges is called!');
    console.log('Changes:'+changes);
  }

  ngOnInit() {
    console.log('Oninit is called');
    console.log('text content:'+this.header.nativeElement.textContent);
    console.log('Paragraph:'+this.paragraph.nativeElement.textContent);
  }

  ngDoCheck()
  {
    console.log('Docheck is called');
  }
  ngAfterContentInit()
  {
    console.log('AfterContentInit is called!');
  }
  ngAfterViewInit()
  {
    console.log('AfterViewInit is called!');
    console.log('Text content:'+this.header.nativeElement.textContent);
  }
  ngAfterViewChecked()
  {
    console.log('AfterViewChecked is called');
  }
  ngAfterContentChecked()
  {
    console.log('AfterContentChecked is called');
  }
  ngOnDestroy()
  {
    console.log('OnDestroy is called');
  }

}
