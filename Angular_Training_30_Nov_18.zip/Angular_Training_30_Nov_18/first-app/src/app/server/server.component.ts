import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'app-server',
    templateUrl: './server.component.html',
    styles: [`
        .online{
            color:white;
        }
        `
        ,
        `.offline{
            color:yellow;
        }
        `
    ]
    //styleUrls: ['./server.component.css']
})
export class ServerComponent implements OnInit{
    serverId: number = 10;
    status: string = 'offline';
    constructor(){
        this.status = Math.random()>0.5?'online':'offline';
    }
    

     ngOnInit(){

      }

      getServerStatus() {
          return this.status;
      }

      getColor()
      {
          return this.status === 'online'?'green':'red';
      }
}