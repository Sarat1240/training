function printMessage(message){
    console.log(message);
}
var message = 'Hello Venky';
printMessage(message);