import { Injectable } from '@angular/core';
import {Http,Response  } from '@angular/http';
//import 'rsjs/RX'
import { Observable } from 'rxjs';
import {map } from 'rxjs/operators';
import { HttpHeaders, HttpClient  } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServersService {

  constructor(private http:HttpClient) {//Http can be replaced with HTTpClient
   
   }
   saveServers(servers:any[])
   {
     const headers = new HttpHeaders(
       {'contentType':'application/json'}
     );
     return this.http.post('https://ng-http-module-633cd.firebaseio.com/data.json',servers,{headers:headers});
   }

   getServers()
   {
     return this.http.get('https://ng-http-module-633cd.firebaseio.com/data.json')
     .pipe(map(
       (response:Response)=>{
         const data=response;
         
         console.log(data);
         return data;
       },
     (error:Response)=>{
      throw Observable.throw('Something went wrong'+error);
     }
     )
     /* .catch(
       (error:Response)=>{
         throw Observable.throw('Something went wrong'+error);
       }*/
     );
   }

   updateServers(servers:any[])
   {
    const headers = new HttpHeaders(
      {'contentType':'application/json'}
    );
    return this.http.put('https://ng-http-module-633cd.firebaseio.com/data.json',servers,{headers:headers});

   }
}
