import { Directive, OnInit, ElementRef, Renderer2, HostListener, HostBinding, Input } from '@angular/core';

@Directive({
  selector: '[appBetterHighlight]'
})
export class BetterHighlightDirective implements OnInit{
  @Input() defaultColor:string='orange';
  @Input() highLightColor:string='violet';
  @HostBinding('style.background-color') backgroundColor:string;

  constructor(private elementref: ElementRef,private renderer: Renderer2) { }
  ngOnInit()
  {
   
   // this.renderer.setStyle(this.elementref.nativeElement,'background-color','orange');
   this.backgroundColor=this.defaultColor;
  }

  @HostListener('mouseover')
  mouseover(eventData:Event)
  {
   // this.renderer.setStyle(this.elementref.nativeElement,'background-color','pink');
   this.backgroundColor=this.highLightColor;
  }

  @HostListener('mouseleave')
  mouseleave(eventData:Event)
  {
   // this.renderer.setStyle(this.elementref.nativeElement,'background-color','violet');
   this.backgroundColor=this.defaultColor;
  }

}
