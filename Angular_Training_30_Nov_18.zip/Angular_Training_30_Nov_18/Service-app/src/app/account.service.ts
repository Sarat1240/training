import { Injectable } from '@angular/core';
import { LoggingService } from './logging.service';
import { EventEmitter } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class AccountService {
  accounts=[
    {name:'Master Account',status:'active'},
    {name:'Test Account',status:'inactive'},
    {name:'Hidden Account',status:'hidden'},
  ];

  statusUpdated = new EventEmitter<string>();

  addAcccount(name:string,status:string)
  {
    this.accounts.push({name:name,status:status});
    this.logService.logStatusChanged(status);
  }

  updateStatus(id:number,newStatus:string)
  {
    this.accounts[id].status=newStatus;
    this.logService.logStatusChanged(newStatus);
  }

  constructor(private logService: LoggingService) { }
}
