class ClassDemo {
   private x: number;
   private y: number;
    constructor( a?:number, b?:number){
        this.x=a;
        this.y=b;

    }
    

    get X(){
        return this.y;
    }
    set X(value){
        if (value<0) {
           throw new Error('value cant less than 0');
        }
    }
    
}

let obj = new ClassDemo(10,-1);
//obj.X = 12;
console.log(obj.X);

//let obj1 = new ClassDemo(20);
//obj.draw();
//obj1.draw();