"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LikeComponent = /** @class */ (function () {
    function LikeComponent(count, status) {
        this.count = count;
        this.status = status;
    }
    LikeComponent.prototype.onclick = function () {
        if (this.status) {
            this.count++;
            this.status = false;
        }
        else {
            this.count--;
            this.status = true;
        }
    };
    Object.defineProperty(LikeComponent.prototype, "Count", {
        get: function () {
            return this.count;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LikeComponent.prototype, "Status", {
        get: function () {
            return this.status;
        },
        enumerable: true,
        configurable: true
    });
    return LikeComponent;
}());
exports.LikeComponent = LikeComponent;
