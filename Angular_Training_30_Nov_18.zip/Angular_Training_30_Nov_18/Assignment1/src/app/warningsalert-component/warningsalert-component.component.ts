import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-warningsalert-component',
  templateUrl: './warningsalert-component.component.html',
  styleUrls: ['./warningsalert-component.component.css']
})
export class WarningsalertComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
