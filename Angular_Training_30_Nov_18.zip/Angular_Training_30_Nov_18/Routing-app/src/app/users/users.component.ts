import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  private users=[
    {id:1,name:'Mr.Federer'},
    {id:2,name:'Mr.Ganguly'},
    {id:3,name:'Mr.Nagarjuna'}
  ];

  constructor() { }

  ngOnInit() {
  }

}
