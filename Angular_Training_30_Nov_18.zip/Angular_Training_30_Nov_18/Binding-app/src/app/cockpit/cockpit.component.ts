import { Component, OnInit,EventEmitter, Output, ViewChild,ElementRef} from '@angular/core';

@Component({
  selector: 'app-cockpit',
  templateUrl: './cockpit.component.html',
  styleUrls: ['./cockpit.component.css']
})
export class CockpitComponent implements OnInit {
  @Output('srvCreated') serverrCreated = new EventEmitter<{name:string,content:string}>();
  @Output('bpCreated') blueprintCreated = new EventEmitter<{name:string,content:string}>();
  //newServerName =  '';
  //newServerContent =  '';
  @ViewChild('serverContentInput') serverContent: ElementRef;



  constructor() { }

  ngOnInit() {
  }

 /*  onAddServer() {
    this.serverrCreated.emit({
      name:this.newServerName,
      content:this.newServerContent

    }); */

    onAddServer(nameInput:HTMLInputElement) {
      this.serverrCreated.emit({
        name:nameInput.value,
        content:this.serverContent.nativeElement.value
  
      });

  }


/* 
  onAddBluePrint() {
    this.blueprintCreated.emit({
      name:this.newServerName,
      content:this.newServerContent

    }); */

    
  onAddBluePrint(nameInput:HTMLInputElement) {
    this.blueprintCreated.emit({
      name:nameInput.value,
      content:this.serverContent.nativeElement.value

    });

   

  }

}
