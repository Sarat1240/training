function vardemo() {
    for (var i = 0; i < 5; i++) {
        console.log(i);
    }
    console.log('i value is' + i);
}
vardemo();
