import { AppPage } from './app.po';

describe('workspace-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display home page message', () => {
    page.navigateTo();
    expect(page.getTitleText()).toEqual('Home Page!');
  });

  it('should display about button', () => {
    page.navigateTo();
    expect(page.getAboutButton().getText()).toEqual('About');
  });

  it('should route to about page', () => {
    page.navigateTo();
    expect(page.getAboutText().getText()).toEqual('About Page!');
  });

});
