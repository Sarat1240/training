import { Component, OnInit } from '@angular/core';
import { resolve,  } from 'dns';
import {  reject } from 'q';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {
  appStatus = new Promise((resolve,reject)=>{
    setTimeout(()=>{resolve('stable');},2000);
  }
  )
  filterStatus='';
  servers=[
    {
      instanceOf:'medium',
      name:'production server',
      status:'stable',
      started: new Date(2017,1,15)
  },
  {
    instanceOf:'large',
    name:'User DB',
    status:'stable',
    started: new Date(2016,2,15)
},
{
  instanceOf:'small',
  name:'Dev server',
  status:'offline',
  started: new Date(2015,3,15)
},
{
  instanceOf:'small',
  name:'Test env server',
  status:'stable',
  started: new Date(2014,4,15)
}
]
  constructor() { }

  ngOnInit() {
  }

  getStatusClasses(server:{instanceOf:string,name:string,status:string,})
  {
    return{
      'list-group-item-success':server.status=='stable',
      'list-group-item-warning':server.status=='offline',
      'list-group-item-danger':server.status=='critical'
    }

  }

  onAddServer()
  {
    this.servers.push({
      instanceOf:'small',
      name:'web server',
      status:'stable',
      started: new Date(2014,4,15)
    })
  }

}
